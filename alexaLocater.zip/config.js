let config = {}

config.tableName = "DeviceLocation"

module.exports = config